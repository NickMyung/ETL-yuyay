date_format = "%Y-%m-%d"
bucket = 'gs://suppliers_tktn'
schema_suppliers = {
    "model": "res.partner",
    "description": "Proveedores registrados en thika thani",
    "object_version": "1.0.0",
    "model_version": "1.0.0",
    "fields" : [
        {
            "name":"write_date",
            "type":"datetime"
        },
        {
            "name": "name",
            "type": "str"
        },
        {
            "name": "purchase_order_count",
            "type": "int" 
        },
        {
            "name": "product_supplierinfo_ids",
            "type": "list"
        }
    ]
}
